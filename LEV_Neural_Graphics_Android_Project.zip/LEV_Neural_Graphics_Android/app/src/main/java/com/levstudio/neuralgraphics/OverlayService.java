package com.levstudio.neuralgraphics;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class OverlayService extends Service {
    public static final String PREFS = "lev_neural_graphics_prefs";
    public static final String ACTION_STOP = "com.levstudio.neuralgraphics.STOP";
    private static final String CHANNEL_ID = "lev_neural_graphics_runtime";
    private static final int NOTIFICATION_ID = 4107;

    private WindowManager windowManager;
    private SharedPreferences prefs;
    private View bubble;
    private LinearLayout panel;
    private FilterOverlayView filterView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams filterParams;
    private boolean panelVisible = false;
    private boolean viewsAdded = false;
    private int screenWidth;
    private int screenHeight;
    private int selectedMode = 1;
    private int intensity = 55;
    private boolean filterEnabled = false;
    private TextView intensityValue;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        readSettings();
        readScreenSize();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, buildNotification());
        }
        if (!android.provider.Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!viewsAdded) addOverlayViews();
        return START_STICKY;
    }

    private void readSettings() {
        filterEnabled = prefs.getBoolean("filter_enabled", false);
        selectedMode = prefs.getInt("filter_mode", 1);
        intensity = prefs.getInt("filter_intensity", 55);
    }

    private void readScreenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect bounds = windowManager.getCurrentWindowMetrics().getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
        } else {
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            windowManager.getDefaultDisplay().getMetrics(dm);
            screenWidth = dm.widthPixels;
            screenHeight = dm.heightPixels;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "LEV Neural Graphics", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the user-enabled LEV floating control available.");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, OverlayService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_lev)
                .setContentTitle("LEV Neural Graphics aktif")
                .setContentText("Ketuk bubble LEV untuk membuka filter warna.")
                .setContentIntent(openPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_lev), "Stop", stopPi).build());
        return builder.build();
    }

    private void addOverlayViews() {
        filterView = new FilterOverlayView(this);
        filterParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        filterParams.gravity = Gravity.TOP | Gravity.START;
        filterParams.x = 0;
        filterParams.y = 0;
        filterParams.alpha = 1f;
        filterView.setVisibility(filterEnabled ? View.VISIBLE : View.GONE);
        filterView.setTint(calculateTint());
        windowManager.addView(filterView, filterParams);

        bubble = createBubble();
        bubbleParams = new WindowManager.LayoutParams(
                dp(58), dp(58),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(10);
        bubbleParams.y = Math.max(dp(100), screenHeight / 2 - dp(29));
        windowManager.addView(bubble, bubbleParams);

        viewsAdded = true;
        applyFilter();
    }

    private View createBubble() {
        LinearLayout container = new LinearLayout(this);
        container.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF8A62FF, 0xFF3A2B98, 0xFF17142D});
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(2), 0xCCFFFFFF);
        container.setBackground(bg);
        container.setElevation(dp(8));
        TextView mark = new TextView(this);
        mark.setText("LEV");
        mark.setTextColor(Color.WHITE);
        mark.setTextSize(15);
        mark.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        container.addView(mark);

        container.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            bubbleParams.x = clamp(startX + (int) dx, 0, Math.max(0, screenWidth - dp(58)));
                            bubbleParams.y = clamp(startY + (int) dy, dp(24), Math.max(dp(24), screenHeight - dp(90)));
                            safeUpdate(bubble, bubbleParams);
                            if (panelVisible) positionPanel();
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                }
                return true;
            }
        });
        return container;
    }

    private void togglePanel() {
        if (panelVisible) closePanel();
        else openPanel();
    }

    private void openPanel() {
        if (panelVisible || !viewsAdded) return;
        panel = createPanel();
        panelParams = new WindowManager.LayoutParams(
                dp(286), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        positionPanel();
        windowManager.addView(panel, panelParams);
        panelVisible = true;
    }

    private void closePanel() {
        if (!panelVisible || panel == null) return;
        try { windowManager.removeView(panel); } catch (Exception ignored) { }
        panel = null;
        panelVisible = false;
    }

    private void positionPanel() {
        if (panelParams == null) return;
        int panelWidth = dp(286);
        int bubbleLeft = bubbleParams != null ? bubbleParams.x : dp(10);
        if (bubbleLeft + dp(58) + panelWidth + dp(12) <= screenWidth) {
            panelParams.x = bubbleLeft + dp(66);
        } else {
            panelParams.x = Math.max(dp(6), bubbleLeft - panelWidth - dp(8));
        }
        panelParams.y = clamp(bubbleParams != null ? bubbleParams.y - dp(24) : dp(100), dp(12), Math.max(dp(12), screenHeight - dp(520)));
        if (panel != null) safeUpdate(panel, panelParams);
    }

    private LinearLayout createPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(16), dp(17), dp(15));
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xF8FFFFFF);
        background.setCornerRadius(dp(22));
        background.setStroke(dp(1), 0xFFE5E2F2);
        box.setBackground(background);
        box.setElevation(dp(14));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        LevLogoView miniLogo = new LevLogoView(this, 38);
        header.addView(miniLogo, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        titleWrap.setPadding(dp(10), 0, 0, 0);
        TextView title = text("LEV Neural Graphics", 16, 0xFF211A3C, true);
        TextView sub = text("FLOATING COLOR FILTER", 9, 0xFF827D92, true);
        titleWrap.addView(title);
        titleWrap.addView(sub);
        header.addView(titleWrap, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = text("×", 27, 0xFF777184, true);
        close.setGravity(Gravity.CENTER);
        header.addView(close, new LinearLayout.LayoutParams(dp(30), dp(38)));
        close.setOnClickListener(v -> closePanel());
        box.addView(header);
        addDivider(box);

        Switch toggle = new Switch(this);
        toggle.setText("Aktifkan Neural Graphics");
        toggle.setTextSize(14);
        toggle.setTextColor(0xFF282438);
        toggle.setChecked(filterEnabled);
        LinearLayout.LayoutParams switchParams = new LinearLayout.LayoutParams(-1, dp(52));
        box.addView(toggle, switchParams);
        toggle.setOnCheckedChangeListener((button, checked) -> {
            filterEnabled = checked;
            prefs.edit().putBoolean("filter_enabled", checked).apply();
            applyFilter();
        });

        TextView modeLabel = text("COLOR PROFILE", 10, 0xFF827D92, true);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2);
        mlp.topMargin = dp(9);
        box.addView(modeLabel, mlp);
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        String[] labels = {"Natural", "Vivid", "Warm", "Cool"};
        for (int i = 0; i < labels.length; i++) {
            final int mode = i;
            TextView chip = text(labels[i], 10, selectedMode == i ? Color.WHITE : 0xFF504A64, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(5), dp(10), dp(5), dp(10));
            chip.setBackground(chipBackground(selectedMode == i));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(38), 1);
            cp.setMargins(dp(2), dp(7), dp(2), 0);
            modes.addView(chip, cp);
            chip.setOnClickListener(v -> {
                selectedMode = mode;
                prefs.edit().putInt("filter_mode", mode).apply();
                // Refresh chip colors without rebuilding the entire panel.
                for (int j = 0; j < modes.getChildCount(); j++) {
                    TextView child = (TextView) modes.getChildAt(j);
                    boolean active = j == mode;
                    child.setTextColor(active ? Color.WHITE : 0xFF504A64);
                    child.setBackground(chipBackground(active));
                }
                applyFilter();
            });
        }
        box.addView(modes);

        LinearLayout intensityRow = new LinearLayout(this);
        intensityRow.setGravity(Gravity.CENTER_VERTICAL);
        intensityRow.setPadding(0, dp(13), 0, 0);
        TextView intensityLabel = text("Intensity", 12, 0xFF3F394F, true);
        intensityRow.addView(intensityLabel, new LinearLayout.LayoutParams(0, -2, 1));
        intensityValue = text(intensity + "%", 12, 0xFF6553E8, true);
        intensityRow.addView(intensityValue);
        box.addView(intensityRow);

        SeekBar seek = new SeekBar(this);
        seek.setMax(100);
        seek.setProgress(intensity);
        LinearLayout.LayoutParams seekp = new LinearLayout.LayoutParams(-1, dp(38));
        box.addView(seek, seekp);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                intensity = value;
                if (intensityValue != null) intensityValue.setText(value + "%");
                if (fromUser) {
                    prefs.edit().putInt("filter_intensity", value).apply();
                    applyFilter();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });

        addDivider(box);
        TextView note = text("Lightweight color-tint overlay. It does not modify game rendering or perform true DLSS / per-pixel neural upscaling.", 10, 0xFF817B8D, false);
        note.setLineSpacing(dp(2), 1f);
        box.addView(note);
        TextView footer = text("Tap the LEV bubble again to close this panel.", 10, 0xFF9B96A7, false);
        LinearLayout.LayoutParams f = new LinearLayout.LayoutParams(-1, -2);
        f.topMargin = dp(8);
        box.addView(footer, f);
        return box;
    }

    private GradientDrawable chipBackground(boolean active) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(active ? 0xFF6553E8 : 0xFFF0EEF7);
        d.setCornerRadius(dp(11));
        return d;
    }

    private void addDivider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(0xFFEAE7F0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.topMargin = dp(12);
        lp.bottomMargin = dp(8);
        parent.addView(line, lp);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private void applyFilter() {
        if (filterView == null) return;
        filterView.setVisibility(filterEnabled && intensity > 0 ? View.VISIBLE : View.GONE);
        filterView.setTint(calculateTint());
        filterView.invalidate();
    }

    private int calculateTint() {
        // This is an explicitly lightweight, translucent color overlay, not framebuffer processing.
        int alpha = Math.min(34, Math.max(0, Math.round(intensity * 0.34f)));
        if (!filterEnabled || intensity == 0) alpha = 0;
        switch (selectedMode) {
            case 1: return Color.argb(alpha, 255, 255, 255);       // Vivid: very subtle lift
            case 2: return Color.argb(alpha, 255, 190, 122);       // Warm
            case 3: return Color.argb(alpha, 145, 207, 255);       // Cool
            default: return Color.argb(Math.min(8, alpha / 4), 255, 255, 255); // Natural
        }
    }

    private void safeUpdate(View view, WindowManager.LayoutParams params) {
        try { windowManager.updateViewLayout(view, params); } catch (Exception ignored) { }
    }

    private int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override
    public void onDestroy() {
        closePanel();
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) { }
            bubble = null;
        }
        if (filterView != null) {
            try { windowManager.removeView(filterView); } catch (Exception ignored) { }
            filterView = null;
        }
        viewsAdded = false;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static class FilterOverlayView extends View {
        private int tint = Color.TRANSPARENT;
        FilterOverlayView(Context context) { super(context); setBackgroundColor(Color.TRANSPARENT); }
        void setTint(int tint) { this.tint = tint; invalidate(); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            if (Color.alpha(tint) > 0) canvas.drawColor(tint);
        }
    }
}
