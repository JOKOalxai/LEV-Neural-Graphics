package com.levstudio.neuralgraphics;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 71;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout root;
    private SharedPreferences prefs;
    private boolean waitingForOverlaySettings = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE);
        Window w = getWindow();
        w.setStatusBarColor(Color.WHITE);
        w.setNavigationBarColor(Color.WHITE);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        showSplash();
        handler.postDelayed(() -> {
            if (Settings.canDrawOverlays(this)) {
                showDoneAndStart();
            } else {
                showPermissionScreen();
            }
        }, 1000L);
    }

    private void baseScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(32), dp(28), dp(32));
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);
    }

    private void showSplash() {
        baseScreen();
        LevLogoView logo = new LevLogoView(this, 92);
        root.addView(logo, new LinearLayout.LayoutParams(dp(92), dp(92)));
        TextView name = label("LEV Neural Graphics", 23, 0xFF17142D, true);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-2, -2);
        np.topMargin = dp(18);
        root.addView(name, np);
        TextView sub = label("Graphics companion for Android", 13, 0xFF7B7B89, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = dp(7);
        root.addView(sub, sp);
    }

    private void showPermissionScreen() {
        baseScreen();
        LevLogoView logo = new LevLogoView(this, 76);
        root.addView(logo, new LinearLayout.LayoutParams(dp(76), dp(76)));

        TextView title = label("Please allow this app to run in background", 21, 0xFF1D1D28, true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(24);
        root.addView(title, tp);

        TextView desc = label("LEV Neural Graphics needs permission to show a floating control bubble above other apps. You can turn this permission off anytime in Android Settings.", 14, 0xFF777783, false);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(-1, -2);
        dpv.topMargin = dp(12);
        root.addView(desc, dpv);

        Button allow = primaryButton("Allow overlay permission");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(28);
        root.addView(allow, bp);
        allow.setOnClickListener(v -> openOverlaySettings());

        TextView foot = label("The floating bubble appears only after you grant permission.", 12, 0xFF9999A4, false);
        foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(18);
        root.addView(foot, fp);
    }

    private void openOverlaySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            waitingForOverlaySettings = true;
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            showDoneAndStart();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (waitingForOverlaySettings && Settings.canDrawOverlays(this)) {
            waitingForOverlaySettings = false;
            showDoneAndStart();
        }
    }

    private void showDoneAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            showPermissionScreen();
            return;
        }
        prefs.edit().putBoolean("setup_done", true).apply();
        baseScreen();
        LevLogoView logo = new LevLogoView(this, 76);
        root.addView(logo, new LinearLayout.LayoutParams(dp(76), dp(76)));

        TextView title = label("Done! now you can use LEV Neural Graphics", 21, 0xFF1D1D28, true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(24);
        root.addView(title, tp);

        TextView check = label("✓", 58, 0xFF1BAA63, true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, dp(72));
        cp.topMargin = dp(9);
        root.addView(check, cp);

        TextView desc = label("The LEV bubble is now available. Tap it to open the graphics panel, drag it to move it, and tap again to close the panel.", 14, 0xFF777783, false);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(-1, -2);
        dpv.topMargin = dp(9);
        root.addView(desc, dpv);

        Button restart = primaryButton("Show floating bubble");
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(54));
        rp.topMargin = dp(25);
        root.addView(restart, rp);
        restart.setOnClickListener(v -> startOverlayService());

        TextView fine = label("For best background reliability, allow background activity in your phone's battery settings if Realme UI offers that option.", 12, 0xFF9999A4, false);
        fine.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(17);
        root.addView(fine, fp);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        } else {
            startOverlayService();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) {
            // The foreground service can still be started when notification permission is denied.
            startOverlayService();
        }
    }

    private void startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            showPermissionScreen();
            return;
        }
        Intent service = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
    }

    private Button primaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(0xFF6553E8, dp(17)));
        b.setElevation(dp(3));
        return b;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
