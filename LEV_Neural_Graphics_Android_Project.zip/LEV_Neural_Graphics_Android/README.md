# LEV Neural Graphics (Android)

A native Android companion app for a movable LEV floating bubble and lightweight color-tint overlay.

## Current implementation

- App label: **LEV Neural Graphics**
- Package: `com.levstudio.neuralgraphics`
- Minimum Android: 8.0 (API 26)
- Compile / target SDK: 35
- Java 17
- No external Android libraries or runtime network dependencies.
- White splash screen for 1 second.
- Permission explanation screen with a button that opens Android's `Display over other apps` permission page.
- Completion screen and a floating LEV bubble after overlay permission is granted.
- Bubble can be dragged. Tap it to open/close the panel.
- Panel includes `Aktifkan Neural Graphics` switch, Natural / Vivid / Warm / Cool profile, and intensity slider.
- A foreground service keeps the bubble available when the activity is closed; Android shows an ongoing notification with a Stop action.
- Filter preferences persist locally.

## Important graphics limitation

This first version is a **translucent screen color-tint overlay**. It does not capture the screen, change another app's rendered pixels, perform per-pixel contrast processing, run a neural network, or provide DLSS-like upscaling. The overlay is deliberately low-opacity and not touchable, so touch input passes to the app beneath it. It is a lightweight visual tint approximation only.

A genuine system-wide neural image enhancement would require a much more complex pipeline and platform-supported screen capture / rendering integration. This app does not request MediaProjection, Accessibility, root, or game-process access.

## Build with Android Studio

The build environment used to prepare this source package did not contain Android SDK Build Tools or Gradle, and outbound access to Google's SDK host was unavailable. Therefore **no compiled APK is included in this package**.

To build:

1. Install Android Studio with Android SDK Platform 35 and Build Tools 35.0.0.
2. Install JDK 17.
3. Open this folder (`LEV_Neural_Graphics_Android`) in Android Studio.
4. Allow Gradle sync to download Android Gradle Plugin 8.7.3 and Gradle 8.9.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

Command line (with Gradle 8.9 and Android SDK 35 installed):

```bash
gradle assembleDebug
```

## Build using GitHub Actions

A workflow is included at `.github/workflows/build-apk.yml`.

1. Create a GitHub repository and upload the contents of this project folder.
2. Push to `main` / `master`, or run the workflow manually from the Actions tab.
3. Download the `LEV-Neural-Graphics-debug-apk` artifact from the completed workflow run.

## Install on Realme / Android

1. Install the generated `app-debug.apk`.
2. Open **LEV Neural Graphics**.
3. Tap **Allow overlay permission**.
4. Android Settings opens the app's **Display over other apps** page. Enable permission and return.
5. The completion screen appears and the LEV bubble is started.
6. Tap the bubble to open the panel; drag to move; tap again to close.
7. Turn **Aktifkan Neural Graphics** on and choose a tint profile.

Realme UI may apply battery restrictions. For better background reliability, allow background activity / auto-launch for LEV Neural Graphics in system app settings if those options are available on the device. Android and OEM settings can still stop background services.

## Permissions

- `SYSTEM_ALERT_WINDOW`: required for the user-approved floating bubble and color overlay.
- `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_SPECIAL_USE`: keep the user-started overlay service active.
- `POST_NOTIFICATIONS`: notification permission on Android 13+; the service has an ongoing notification and a Stop action.

The app does not request Internet, storage, contacts, microphone, camera, or Accessibility permissions.
