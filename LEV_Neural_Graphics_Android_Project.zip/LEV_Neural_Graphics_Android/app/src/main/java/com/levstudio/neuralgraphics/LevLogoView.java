package com.levstudio.neuralgraphics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.view.View;

public class LevLogoView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int sizeDp;

    public LevLogoView(Context context, int sizeDp) {
        super(context);
        this.sizeDp = sizeDp;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) * 0.47f;
        p.setShader(new LinearGradient(0, 0, w, h, new int[]{0xFF8A62FF, 0xFF4030A8, 0xFF17142D}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
        p.setShader(null);
        p.setColor(0x553B2A92);
        c.drawCircle(cx - r * 0.23f, cy - r * 0.25f, r * 0.72f, p);
        p.setColor(Color.WHITE);
        p.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(r * 0.61f);
        c.drawText("LEV", cx, cy + r * 0.22f, p);
        p.setColor(0xFFFFD66B);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx + r * 0.57f, cy - r * 0.52f, r * 0.09f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2f, r * 0.045f));
        p.setColor(0x99FFFFFF);
        c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.FILL);
    }
}
